Locking System Mobile Application.

Platform: ios 11.1
swift v3.0
Xcode v9.1
CocoaPods v1.1.1

This application will be integrated with the smart locking system units in order to give the users the ability to monitor and track their locking systems from anywhere and at anytime. 

1) Install Xcode from App store.
2) Install Cocoapods package.
4) Create a new project in Xcode and add the content of this folder to it.

