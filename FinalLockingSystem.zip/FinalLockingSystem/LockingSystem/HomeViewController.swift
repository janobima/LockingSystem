//
//  ViewController.swift
//  LockingSystem
//
//  Created by Maryam AlJanobi on 9/16/17.
//  Copyright © 2017 UNH. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
}

