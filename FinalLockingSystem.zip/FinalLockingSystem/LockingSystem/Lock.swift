//
//  Lock.swift
//  LockingSystem
//
//  Created by Maryam AlJanobi on 9/23/17.
//  Copyright © 2017 UNH. All rights reserved.
//

import UIKit
import CoreData

// Auto Generated Class for Core Data
class Lock: NSManagedObject {

}
